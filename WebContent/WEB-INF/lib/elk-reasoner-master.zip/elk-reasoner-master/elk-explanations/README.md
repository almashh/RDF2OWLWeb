explanation-workbench
=====================

A plug-in that adds explanation facilities to the Protege Desktop ontology editor.
